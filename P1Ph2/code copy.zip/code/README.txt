The following package contains the solutions for P1Ph2. The trajectory folder contains the two tejactory files namely circle and diamond.

For circle trajectory I have used the bell curve equation to analyze the velocity and acceleration changes during the motion. 

For Diamond trajectory I divided the four corners based on equal time stamps and calculated he position and other parameters.

For controller, I followed the Mellinger thesis.

My trajectory calculations were inspired by the Coursera couse contents from MEAM 620.
